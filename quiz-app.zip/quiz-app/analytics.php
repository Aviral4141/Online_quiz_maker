<?php
include 'includes/config.php';
include 'includes/header.php';

if ($_SESSION['role'] !== 'examiner') {
    echo "<p>Access denied.</p>";
    include 'includes/footer.php';
    exit;
}

$stmt = $pdo->prepare("SELECT id, title FROM quizzes WHERE creator_id=?");
$stmt->execute([$_SESSION['user_id']]);
$quizzes = $stmt->fetchAll();
?>

<div class="card">
    <h2>Your Quiz Analytics</h2>
    <ul>
        <?php foreach($quizzes as $quiz): ?>
            <li>
                <strong><?php echo htmlspecialchars($quiz['title']); ?></strong>
                <?php
                // Get attempts and average score
                $stmt2 = $pdo->prepare("SELECT COUNT(*) as cnt, AVG(score) as avg_score FROM attempts WHERE quiz_id=?");
                $stmt2->execute([$quiz['id']]);
                $row = $stmt2->fetch();
                ?>
                <br>
                Attempts: <?php echo $row['cnt']; ?>, 
                Average Score: <?php echo round($row['avg_score'],2); ?>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

<?php include 'includes/footer.php'; ?>
