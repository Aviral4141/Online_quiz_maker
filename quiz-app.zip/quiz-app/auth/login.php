<?php
include '../includes/config.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = "All fields are required.";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            header("Location: ../dashboard.php");
            exit;
        } else {
            $error = "Invalid username or password.";
        }
    }
}

include '../includes/header.php';
?>

<div class="form-container">
    <div class="card p-4" style="min-width:340px; max-width:400px;">
        <h2 class="mb-4 text-center text-primary">Login to QuizMaker</h2>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" autocomplete="off">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" name="username" id="username" 
                       class="form-input form-control" required>
            </div>
            
            <div class="mb-4">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="password" 
                       class="form-input form-control" required>
            </div>
            
            <button type="submit" class="form-button w-100">Sign In</button>
            
            <p class="text-center mt-3">
                Don't have an account? 
                <a href="register.php" class="text-primary">Register here</a>
            </p>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
