<?php
include '../includes/config.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'participant';

    if ($username === '' || $password === '') {
        $error = "All fields are required.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = "Username already taken.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
            if ($stmt->execute([$username, $hash, $role])) {
                $_SESSION['user_id'] = $pdo->lastInsertId();
                $_SESSION['username'] = $username;
                $_SESSION['role'] = $role;
                header("Location: ../dashboard.php");
                exit;
            } else {
                $error = "Registration failed. Try again.";
            }
        }
    }
}
    
include '../includes/header.php';
?>

<div class="form-container">
    <div class="card p-4" style="min-width:340px; max-width:400px;">
        <h2 class="mb-4 text-center text-primary">Create Account</h2>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="POST" autocomplete="off">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" name="username" id="username" class="form-input form-control" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="password" class="form-input form-control" required>
            </div>
            <div class="mb-4">
                <label for="role" class="form-label">Role</label>
                <select name="role" id="role" class="form-select form-input">
                    <option value="participant">Participant</option>
                    <option value="examiner">Examiner</option>
                </select>
            </div>
            <button type="submit" class="form-button w-100">Register Now</button>
            <p class="text-center mt-3">
                Already have an account?
                <a href="login.php" class="text-primary">Sign in</a>
            </p>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
