<?php
include 'includes/config.php';
include 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit;
}

// Get dashboard stats
$quizCount = $pdo->query("SELECT COUNT(*) FROM quizzes")->fetchColumn();
$userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$attemptCount = $pdo->query("SELECT COUNT(*) FROM attempts")->fetchColumn();
?>

<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="p-4 dashboard-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-0">Welcome back, <?php echo $_SESSION['username']; ?>!</h1>
                    <p class="text-muted mb-0"><?php date_default_timezone_set('UTC'); echo date('l, F j'); ?></p>
                </div>
                <div class="d-flex gap-3">
                    <div class="text-center">
                        <div class="stats-badge rounded-pill p-3">
                            <div class="h4 mb-0"><?php echo $quizCount; ?></div>
                            <small>Quizzes</small>
                        </div>
                    </div>
                    <div class="text-center">
                        <div class="stats-badge rounded-pill p-3">
                            <div class="h4 mb-0"><?php echo $userCount; ?></div>
                            <small>Users</small>
                        </div>
                    </div>
                    <div class="text-center">
                        <div class="stats-badge rounded-pill p-3">
                            <div class="h4 mb-0"><?php echo $attemptCount; ?></div>
                            <small>Attempts</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if($_SESSION['role'] === 'examiner'): ?>
<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="p-4 dashboard-card h-100">
            <h5 class="mb-3">Quick Actions</h5>
            <a href="quiz/create.php" class="btn btn-primary w-100 mb-3">+ New Quiz</a>
            <div class="list-group">
                <a href="analytics.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                    View Analytics
                    <span class="badge bg-primary rounded-pill"><?php echo $quizCount; ?></span>
                </a>
                <a href="leaderboard.php" class="list-group-item list-group-item-action">Top Performers</a>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="p-4 dashboard-card h-100">
            <h5 class="mb-3">Your Recent Quizzes</h5>
            <div class="row g-3">
            <?php
            $stmt = $pdo->prepare("SELECT quizzes.*, COUNT(questions.id) as question_count 
                                 FROM quizzes LEFT JOIN questions ON quizzes.id = questions.quiz_id 
                                 WHERE creator_id = ? GROUP BY quizzes.id ORDER BY created_at DESC LIMIT 3");
            $stmt->execute([$_SESSION['user_id']]);
            while($quiz = $stmt->fetch()):
            ?>
                <div class="col-12">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title mb-1"><?php echo htmlspecialchars($quiz['title']); ?></h6>
                                    <small class="text-muted">
                                        <?php echo $quiz['question_count']; ?> questions • 
                                        Created <?php echo date('M j', strtotime($quiz['created_at'])); ?>
                                    </small>
                                </div>
                                <div class="dropdown">
                                    <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="dropdown">
                                        <i class="bi bi-three-dots-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end">
                                        <li><a class="dropdown-item" href="quiz/edit.php?id=<?php echo $quiz['id']; ?>">Edit</a></li>
                                        <li><a class="dropdown-item" href="analytics.php?quiz_id=<?php echo $quiz['id']; ?>">Analytics</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="row g-4">
    <div class="col-12">
        <div class="p-4 dashboard-card">
            <h5 class="mb-4">Available Quizzes</h5>
            <div class="row g-3">
            <?php
            $stmt = $pdo->query("SELECT quizzes.*, COUNT(questions.id) as question_count 
                               FROM quizzes LEFT JOIN questions ON quizzes.id = questions.quiz_id 
                               GROUP BY quizzes.id");
            while($quiz = $stmt->fetch()):
            ?>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <h6 class="card-title"><?php echo htmlspecialchars($quiz['title']); ?></h6>
                            <p class="text-muted small mb-3">
                                <?php echo $quiz['question_count']; ?> questions • 
                                <?php echo rand(50, 200); ?> participants
                            </p>
                            <a href="quiz/take.php?quiz_id=<?php echo $quiz['id']; ?>" 
                               class="btn btn-sm btn-outline-primary w-100">
                               Start Quiz
                            </a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
