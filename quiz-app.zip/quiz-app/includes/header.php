<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Maker</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-blue: #1a73e8;
            --secondary-blue: #4285f4;
            --light-bg: #f8f9fa;
        }
        body {
            background: var(--light-bg);
            padding-top: 80px;
        }
        .navbar-brand {
            font-weight: 600;
            color: var(--primary-blue) !important;
        }
        .dashboard-card {
            background: white;
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(50, 50, 93, 0.11);
            transition: transform 0.2s;
        }
        .dashboard-card:hover {
            transform: translateY(-5px);
        }
        .stats-badge {
            background: linear-gradient(45deg, var(--primary-blue), var(--secondary-blue));
            color: white !important;
        }
        .nav-link.active {
            border-bottom: 3px solid var(--primary-blue);
            font-weight: 500;
        }
        .role-badge {
            background: #e8f0fe;
            color: var(--primary-blue);
        }
        /* Form centering and style */
        .form-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            border-radius: 16px;
            box-shadow: 0 4px 24px 0 rgba(60,72,88,.08);
            border: none;
        }
        .form-label {
            color: #1a73e8;
            font-weight: 500;
        }
        .form-input, .form-select {
            border-radius: 8px;
            border: 1.5px solid #e2e8f0;
            padding: 0.75rem 1rem;
            transition: border-color .2s;
        }
        .form-input:focus, .form-select:focus {
            border-color: #1a73e8;
            box-shadow: 0 0 0 2px #e8f0fe;
        }
        .form-button {
            background: linear-gradient(90deg, #1a73e8, #4285f4);
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: background .2s;
        }
        .form-button:hover {
            background: linear-gradient(90deg, #4285f4, #1a73e8);
        }
        .loading-spinner {
            animation: spin 1s linear infinite;
            width: 1.5rem;
            height: 1.5rem;
            border: 3px solid #e2e8f0;
            border-top-color: #1a73e8;
            border-radius: 50%;
            display: inline-block;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="/quiz-app/index.php">QuizMaker</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <a class="nav-link active" href="/quiz-app/dashboard.php">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/quiz-app/leaderboard.php">Leaderboard</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <span class="role-badge px-3 py-1 rounded-pill">
                                    <?php echo ucfirst($_SESSION['role']) ?>
                                </span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="/quiz-app/analytics.php">Analytics</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="/quiz-app/auth/logout.php">Log Out</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="btn btn-outline-primary me-2" href="/quiz-app/auth/login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-primary" href="/quiz-app/auth/register.php">Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <main class="container">
