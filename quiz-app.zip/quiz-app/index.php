<?php
include 'includes/config.php';
include 'includes/header.php';
?>
<div class="card" style="text-align:center;">
    <h1>Welcome to the Online Quiz Maker!</h1>
    <p style="margin:1rem 0;">Create and take quizzes, compete on the leaderboard, and track your performance!</p>
    <a href="dashboard.php" class="btn">Go to Dashboard</a>
</div>
<?php include 'includes/footer.php'; ?>
