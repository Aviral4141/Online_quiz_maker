<?php
include 'includes/config.php';
include 'includes/header.php';

$stmt = $pdo->query("SELECT u.username, q.title, a.score, a.attempted_at
    FROM attempts a
    JOIN users u ON a.user_id = u.id
    JOIN quizzes q ON a.quiz_id = q.id
    ORDER BY a.score DESC, a.attempted_at ASC
    LIMIT 10");
$leaders = $stmt->fetchAll();
?>

<div class="card">
    <h2>Leaderboard</h2>
    <table border="1" cellpadding="8" style="width:100%; background:white;">
        <tr style="background:#e3f2fd;">
            <th>User</th>
            <th>Quiz</th>
            <th>Score</th>
            <th>Date</th>
        </tr>
        <?php foreach($leaders as $row): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['username']); ?></td>
            <td><?php echo htmlspecialchars($row['title']); ?></td>
            <td><?php echo $row['score']; ?></td>
            <td><?php echo $row['attempted_at']; ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
