<?php
include '../includes/config.php';

// Handle authorization and redirects before any output
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'examiner') {
    header("Location: ../index.php");
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();

        // Create quiz
        $stmt = $pdo->prepare("INSERT INTO quizzes (title, creator_id) VALUES (?, ?)");
        $stmt->execute([$_POST['title'], $_SESSION['user_id']]);
        $quiz_id = $pdo->lastInsertId();
        
        // Add questions
        foreach($_POST['questions'] as $question) {
            if (empty($question['text'])) {
                throw new Exception('All questions must have text');
            }
            
            $stmt = $pdo->prepare("INSERT INTO questions (quiz_id, question_text) VALUES (?, ?)");
            $stmt->execute([$quiz_id, trim($question['text'])]);
            $question_id = $pdo->lastInsertId();
            
            // Add options
            $hasCorrect = false;
            foreach($question['options'] as $option) {
                if (empty($option['text'])) {
                    throw new Exception('All options must have text');
                }
                
                $isCorrect = isset($option['is_correct']) ? 1 : 0;
                if ($isCorrect) $hasCorrect = true;
                
                $stmt = $pdo->prepare("INSERT INTO options (question_id, option_text, is_correct) VALUES (?, ?, ?)");
                $stmt->execute([$question_id, trim($option['text']), $isCorrect]);
            }
            
            if (!$hasCorrect) {
                throw new Exception('Each question must have at least one correct answer');
            }
        }
        
        $pdo->commit();
        header("Location: ../dashboard.php");
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = $e->getMessage();
    }
}

include '../includes/header.php';
?>

<div class="form-container">
    <div class="card p-4" style="max-width: 800px;">
        <h2 class="mb-4 text-center text-primary">Create New Quiz</h2>
        
        <?php if ($error): ?>
        <div class="alert alert-danger mb-4"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" id="quizForm">
            <div class="mb-4">
                <label class="form-label">Quiz Title</label>
                <input type="text" name="title" class="form-control form-input" 
                       placeholder="Enter quiz title" required>
            </div>

            <div id="questions" class="mb-4">
                <!-- Question template will be cloned here -->
                <div class="question-card mb-4 p-3 border rounded">
                    <div class="mb-3">
                        <label class="form-label">Question 1</label>
                        <input type="text" name="questions[0][text]" 
                               class="form-control form-input" 
                               placeholder="Enter question text" required>
                    </div>
                    
                    <div class="options mb-3">
                        <div class="option-item mb-2">
                            <div class="input-group">
                                <input type="text" name="questions[0][options][0][text]"
                                       class="form-control form-input"
                                       placeholder="Enter option" required>
                                <div class="input-group-text bg-transparent border-0">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox"
                                               name="questions[0][options][0][is_correct]">
                                        <label class="form-check-label small">Correct</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <button type="button" class="btn btn-sm btn-outline-primary add-option">
                        <i class="bi bi-plus-circle"></i> Add Option
                    </button>
                </div>
            </div>

            <div class="d-flex gap-2">
                <button type="button" id="addQuestion" class="btn btn-primary">
                    <i class="bi bi-plus-lg"></i> Add Question
                </button>
                <button type="submit" class="btn btn-success flex-grow-1">
                    <i class="bi bi-save"></i> Create Quiz
                </button>
            </div>
        </form>
    </div>
</div>

<script>
let questionCount = 0;
document.getElementById('addQuestion').addEventListener('click', () => {
    questionCount++;
    const newQuestion = document.querySelector('.question-card').cloneNode(true);
    
    // Update all names and labels
    newQuestion.innerHTML = newQuestion.innerHTML
        .replace(/questions\[0\]/g, `questions[${questionCount}]`)
        .replace(/Question 1/g, `Question ${questionCount + 1}`);
    
    // Reset option checkboxes
    newQuestion.querySelectorAll('.form-check-input').forEach(checkbox => {
        checkbox.checked = false;
    });
    
    document.getElementById('questions').appendChild(newQuestion);
});

document.addEventListener('click', (e) => {
    if(e.target.closest('.add-option')) {
        const optionsDiv = e.target.closest('.question-card').querySelector('.options');
        const optionCount = optionsDiv.children.length;
        const newOption = optionsDiv.children[0].cloneNode(true);
        
        // Update option name indexes
        newOption.innerHTML = newOption.innerHTML
            .replace(/\[options\]\[0\]/g, `[options][${optionCount}]`);
        
        // Clear input and checkbox
        newOption.querySelector('input[type="text"]').value = '';
        newOption.querySelector('.form-check-input').checked = false;
        
        optionsDiv.appendChild(newOption);
    }
});
</script>

<?php include '../includes/footer.php'; ?>
