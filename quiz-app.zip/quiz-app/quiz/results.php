<?php
include '../includes/config.php';
include '../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['quiz_id'])) {
    echo "<p>Invalid attempt.</p>";
    include '../includes/footer.php';
    exit;
}

$quiz_id = intval($_POST['quiz_id']);
$user_id = $_SESSION['user_id'] ?? 0;
$score = 0;

// Fetch correct answers
$stmt = $pdo->prepare("SELECT q.id as qid, o.id as oid, o.is_correct 
                       FROM questions q JOIN options o ON q.id=o.question_id 
                       WHERE q.quiz_id=?");
$stmt->execute([$quiz_id]);
$correct = [];
foreach ($stmt->fetchAll() as $row) {
    if ($row['is_correct']) {
        $correct[$row['qid']] = $row['oid'];
    }
}

// Calculate score
foreach ($correct as $qid => $oid) {
    if (isset($_POST['answers'][$qid]) && $_POST['answers'][$qid] == $oid) {
        $score++;
    }
}

// Save attempt
$stmt = $pdo->prepare("INSERT INTO attempts (user_id, quiz_id, score) VALUES (?, ?, ?)");
$stmt->execute([$user_id, $quiz_id, $score]);

echo "<div class='card'>";
echo "<h2>Your Score: $score / ".count($correct)."</h2>";
echo "<a href='../dashboard.php' class='btn'>Back to Dashboard</a>";
echo "</div>";

include '../includes/footer.php';
?>
