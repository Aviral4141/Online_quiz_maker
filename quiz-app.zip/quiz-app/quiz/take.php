<?php
include '../includes/config.php';
include '../includes/header.php';

if (!isset($_GET['quiz_id'])) {
    echo '<div class="form-container"><div class="alert alert-danger">Quiz not found.</div></div>';
    include '../includes/footer.php';
    exit;
}

$quiz_id = intval($_GET['quiz_id']);

// Fetch quiz info
$stmt = $pdo->prepare("SELECT * FROM quizzes WHERE id = ?");
$stmt->execute([$quiz_id]);
$quiz = $stmt->fetch();

if (!$quiz) {
    echo '<div class="form-container"><div class="alert alert-danger">Quiz not found.</div></div>';
    include '../includes/footer.php';
    exit;
}

// Fetch questions and options
$stmt = $pdo->prepare("SELECT * FROM questions WHERE quiz_id = ?");
$stmt->execute([$quiz_id]);
$questions = $stmt->fetchAll();

$qs = [];
foreach ($questions as $q) {
    $stmt2 = $pdo->prepare("SELECT * FROM options WHERE question_id = ?");
    $stmt2->execute([$q['id']]);
    $qs[] = [
        'id' => $q['id'],
        'text' => $q['question_text'],
        'options' => $stmt2->fetchAll()
    ];
}
?>

<div class="form-container">
    <div class="card p-4" style="max-width: 600px; width:100%;">
        <h2 class="mb-4 text-center text-primary"><?php echo htmlspecialchars($quiz['title']); ?></h2>
        <form method="POST" action="results.php">
            <input type="hidden" name="quiz_id" value="<?php echo $quiz_id; ?>">
            <?php foreach ($qs as $i => $q): ?>
                <div class="mb-4">
                    <label class="form-label fw-bold">
                        <?php echo ($i+1) . ". " . htmlspecialchars($q['text']); ?>
                    </label>
                    <?php foreach ($q['options'] as $opt): ?>
                        <div class="form-check mb-1">
                            <input class="form-check-input" type="radio"
                                   name="answers[<?php echo $q['id']; ?>]"
                                   value="<?php echo $opt['id']; ?>" id="q<?php echo $q['id']; ?>o<?php echo $opt['id']; ?>" required>
                            <label class="form-check-label" for="q<?php echo $q['id']; ?>o<?php echo $opt['id']; ?>">
                                <?php echo htmlspecialchars($opt['option_text']); ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
            <button type="submit" class="form-button w-100">Submit Quiz</button>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
